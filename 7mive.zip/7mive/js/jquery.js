$(document).ready(function () {
    window.onscroll = function () {
        myFunction()
    };
    var header = document.getElementById("grouping");
    var sticky = header.offsetTop;

    function myFunction() {
        if (window.pageYOffset > sticky) {
            header.classList.add("sticky");
        } else {
            header.classList.remove("sticky");
        }
    }

    ////////////////side bar /////////////////
    $(".box-group").click(function () {
        $(".box-group").removeClass("active-grouping");
        $(this).addClass("active-grouping");
        var atr = $(this).attr("data-name");
        $(".mv").css("display", "none");
        $("." + atr).css("display", "block");

    })

    /*********************End side bar*************************************/

    $(".menu").click(function () {
        $(".main").toggleClass("main-blur");
        $(".sidebar").toggleClass("active-sidebar");

    })
    $(".lili").click(function () {
        alert("hello");
    })

})